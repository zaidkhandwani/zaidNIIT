﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Ashar
{
    public partial class Form1 : Form
    {
        string conn = System.Configuration.ConfigurationManager.AppSettings["connection"];
        string uName = "";
        string role = "";
        string roll = "";
        string batch = "";
        string uRfid = "";
        string tRfid = "";
        string currentPeriod = "";
        string periodType = "";
        string currentSubject = "";
        string batchA_Practical = "";
        string batchB_Practical = "";
        string batchC_Practical = "";
        

        bool teacherPresent;
        bool batchA_teacherPresent;
        bool batchB_teacherPresent;
        bool batchC_teacherPresent;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            //this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            tableLayoutPanel1.Width = this.Size.Width - (6 * (tableLayoutPanel1.Margin.Left));
            tableLayoutPanel2.Width = tableLayoutPanel1.Width;//this.Size.Width - (7 * (tableLayoutPanel2.Margin.Left));
            tableLayoutPanel3.Width = this.Size.Width - (7 * (tableLayoutPanel3.Margin.Left));
            tableLayoutPanel4.Width = this.Size.Width - (7 * (tableLayoutPanel4.Margin.Left));

            int cols = tableLayoutPanel3.ColumnCount;
            int wid = tableLayoutPanel3.Width / cols;
            for (int i = 0; i < cols; i++)
                tableLayoutPanel3.ColumnStyles[i].Width = wid;

            string[] portnames = SerialPort.GetPortNames();
            comboBox1.Items.Add("Select Port");
            for (int i = 0; i < portnames.Length; i++)
            {
                comboBox1.Items.Add(portnames[i]);
            }
            try
            {
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error", "Please Connect the Reader !");
            }
            backgroundWorker1.RunWorkerAsync();
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            tableLayoutPanel1.Width = this.Size.Width - (5 * (tableLayoutPanel1.Margin.Left));
            tableLayoutPanel2.Width = this.Size.Width - (5 * (tableLayoutPanel2.Margin.Left));
            tableLayoutPanel3.Width = this.Size.Width - (5 * (tableLayoutPanel3.Margin.Left));
            tableLayoutPanel4.Width = this.Size.Width - (5 * (tableLayoutPanel4.Margin.Left));

            int cols = tableLayoutPanel3.ColumnCount;
            int wid = tableLayoutPanel3.Width / cols;
            for (int i = 0; i < cols; i++)
                tableLayoutPanel3.ColumnStyles[i].Width = wid;

            int cols2 = tableLayoutPanel4.ColumnCount;
            int wid2 = tableLayoutPanel4.Width / cols2;
            for (int i = 0; i < cols2; i++)
                tableLayoutPanel4.ColumnStyles[i].Width = wid2;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegisterForm rf = new RegisterForm();
            rf.StartPosition = FormStartPosition.CenterScreen;
            rf.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = comboBox1.Text;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            String rfid = "";
            if (serialPort1.IsOpen)
            {
                if (serialPort1.BytesToRead > 0)
                {

                    for (int i = 0; i < 12; i++)
                    {
                        char c = (char)serialPort1.ReadChar();
                        rfid += c;
                    }
                }
                rfidTxt.Invoke((MethodInvoker)delegate { rfidTxt.Text = rfid; });
                if (Authenticate(rfid))
                {
                    if (role.Equals("Teacher"))
                    {
                        getCurrentPeriod();
                        if (periodType.Equals("Lecture"))
                        {
                            getTeacherSubject(tRfid);
                            teacherPresent = true;
                            //teacher attendance
                        }else
                        {
                            getCurrentPractical();
                            //teacher attendance
                        }
                    }
                    else
                    {
                        if (teacherPresent)
                        {

                        }else
                        {
                            uNametxt.Invoke((MethodInvoker)delegate
                            {
                                uNametxt.ForeColor = System.Drawing.Color.Red;
                                uNametxt.Text = "Please wait for the Teacher !";
                            });
                        }
                        
                    }
                }
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
        }

        private bool Authenticate(string rfid)
        {
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
            {
                string sql = "select * from User where Rfid = '" + rfid + "'";
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);

                System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                    while (sdr.Read())
                    {
                        uName = sdr["Name"].ToString();
                        string tempRfid = sdr["Rfid"].ToString();
                        
                        role = sdr["Role"].ToString();
                        roll = sdr["Roll"].ToString();
                        batch = sdr["Batch"].ToString();
                        if (role.Equals("Teacher")) tRfid = tempRfid;
                        else
                        {
                            uRfid = tempRfid;

                        }

                        //string sub = sdr["Subject"].ToString();
                        //if (sub != null && !sub.Equals("")) currentSubject = sub;
                    }
                    
                    uNametxt.ForeColor = System.Drawing.Color.Green;
                    uNametxt.Text = uName;
                    return true;
                }
                else
                {   
                    uNametxt.Invoke((MethodInvoker)delegate {
                        uNametxt.ForeColor = System.Drawing.Color.Red;
                        uNametxt.Text = "Invalid User";
                    });
                    
                    return false;
                }

            }
        }

        private void IsTeacher(string rfid)
        {

        }

        private string getCurrentPeriod()
        {
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
            {
                string sql = "select * from TimeTable where StartTime <= '" + System.DateTime.Now.ToString("hh:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo) + "' and StopTime >'" + System.DateTime.Now.ToString("hh:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo) + "'";
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);

                System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                    while (sdr.Read())
                    {
                        currentPeriod = sdr["Period"].ToString();
                        periodType = sdr["Period"].ToString();
                    }
                }

            }
            return currentPeriod;
        }

        private string getTeacherSubject(string trfid)
        {
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
            {
                string sql = "select * from User where Rfid = '"+trfid+"'";
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);

                System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                    while (sdr.Read())
                    {
                        currentSubject = sdr["Subject"].ToString();
                    }
                }

            }
            return currentSubject;
        }

        private void getCurrentPractical()
        {
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
            {
                string sql = "select * from TimeTable where StartTime <= '" + System.DateTime.Now.ToString("hh:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo) + "' and StopTime >'" + System.DateTime.Now.ToString("hh:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo) + "'";
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);

                System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.HasRows)
                {
                    while (sdr.Read())
                    {
                        batchA_Practical = sdr["BAS"].ToString();
                        batchB_Practical = sdr["BBS"].ToString();
                        batchC_Practical = sdr["BCS"].ToString();
                    }
                }

            }
        }
    }
}