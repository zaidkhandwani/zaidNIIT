﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string rfid;
        string output = "";
        private float balanceAmt;
        private string customerType;
        private float depositAmt;
        private string milkType;
        private float fixedQuantity;
        private float poactualcost;
        private float poquantity;
        private float totalprice;
        private float orderQuantity;
        string conn = System.Configuration.ConfigurationManager.AppSettings["kavitadairy"].ToString();
        MySqlConnection con = new MySqlConnection("server = 132.148.19.6; user id =vaisansa_dbuser; password=Vaisansar123@; database =vaisansa_db;");
        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

            textBox1.Text = serialPort1.PortName.ToString();

            if (serialPort1 != null)
            {
                try { serialPort1.Open();

                    backgroundWorker1.RunWorkerAsync(); }
                catch(Exception)
                {
                    MessageBox.Show("Please Connect Receiver to Serial Port");
                }
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            string b = serialPort1.ReadLine();
            textBox1.Invoke((MethodInvoker)delegate { textBox1.Text = b; });
            string[] data = b.Split("-".ToCharArray());

            switch (data[0])
            {
                case "1":
                    {
                        customerType = null;
                        string input = data[1].ToString();
                        string dec = data[1].Substring(2, 8);
                        long num = Int64.Parse(dec, System.Globalization.NumberStyles.HexNumber);
                        rfid = num.ToString().PadLeft(10, '0');


                        string sql = "select * from User where rfidno='" + rfid + "' ";
                        MySqlCommand cmd = new MySqlCommand(sql, con);
                        try { con.Open(); }
                        catch (Exception) {  serialPort1.WriteLine("2-Connection is not open. Please Connect to Server via Internet"); }
                        MySqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            while (sdr.Read())
                            {
                                depositAmt = float.Parse(sdr["depositamt"].ToString());
                                milkType = sdr["milktype"].ToString();
                                customerType = sdr["customertype"].ToString();
                                balanceAmt = float.Parse(sdr["balanceamt"].ToString());
                                fixedQuantity = float.Parse(sdr["fixedquantity"].ToString());

                            }
                        }
                        sdr.Close();

                        if (customerType != null)
                        {
                            sql = "select * from Productout where poname ='" + milkType + "' ";
                            MySqlCommand cmd1 = new MySqlCommand(sql, con);

                            MySqlDataReader sdr1 = cmd1.ExecuteReader();
                            if (sdr1.HasRows)
                            {
                                while (sdr1.Read())
                                {
                                    poactualcost = float.Parse(sdr1["poactualcost"].ToString());
                                    poquantity = float.Parse(sdr1["poquantity"].ToString());
                                }
                            }

                            if (customerType.Equals("prepaid"))
                            {

                                totalprice = (fixedQuantity * poactualcost);

                                if (depositAmt >= totalprice)
                                {
                                    output = "1-" + customerType + "-" + milkType + "-" + fixedQuantity + " L-Balance : Rs " + depositAmt + "-Allowed";
                                }
                                else
                                {
                                    output = "1-" + customerType + "-" + milkType + "-" + fixedQuantity + " L-Balance : Rs " + depositAmt + "-Disallowed";
                                }
                            }
                            else
                            {
                                totalprice = (fixedQuantity * poactualcost);
                                output = "1-" + customerType + "-" + milkType + "-" + fixedQuantity + " L-Credit : Rs " + balanceAmt + "-Allowed";
                            }

                            serialPort1.WriteLine(output);
                        }

                        else
                        {
                            output = "1-Invalid User- - - ";
                            serialPort1.WriteLine(output);
                        }
                        con.Close();
                    }
                    break;

                case "2":
                    {
                        string input = data[1].ToString();
                      
                        
                        if (input.Equals("*\r"))
                        {
                            serialPort1.WriteLine("2-Processing...");
                            float updatedAmt;
                            string sql = "";
                            if (customerType.Equals("prepaid"))
                            {
                                updatedAmt = depositAmt - totalprice;
                                sql = "Update User set depositamt = '" + updatedAmt + "' where rfidno = '" + rfid + "'";

                            }
                            else
                            {
                                updatedAmt = balanceAmt + totalprice;
                                sql = "Update User set balanceAmt = '" + updatedAmt + "' where rfidno = '" + rfid + "'";
                            }
                            DateTime today = DateTime.Today;
                            string currentDate = today.ToString("dd-MM-yy");

                            float updatedQuantity = poquantity - fixedQuantity;
                            string sql2 = "INSERT INTO PrepaidSales (date, pamt, pname, pquantity, salesmanname, userrfid) VALUES('" + currentDate + "', '" + totalprice + "','" + milkType + "','" + fixedQuantity + "', 'Milk Counter', '" + rfid + "'); ";
                            string sql3 = "Update Productout set poquantity = '" + updatedQuantity + "' where poname = '" + milkType + "'";
                            MySqlCommand cmd1 = new MySqlCommand(sql, con);
                            try { con.Open(); }
                            catch (Exception) { serialPort1.WriteLine("2-Connection is not open. Please Connect to Server via Internet"); }
                            int i = cmd1.ExecuteNonQuery();
                            MySqlCommand cmd2 = new MySqlCommand(sql2, con);
                            int j = cmd2.ExecuteNonQuery();
                            MySqlCommand cmd3 = new MySqlCommand(sql3, con);
                            int k = cmd3.ExecuteNonQuery();
                            if (i > 0)
                            {
                                serialPort1.WriteLine("2-Done ! Bill: Rs" + totalprice +"");
                            }
                            else
                            {
                                serialPort1.WriteLine("2-Please Try Again !");
                            }
                        }
                        else if (input.Equals("B") || (input.Equals("C")))
                        {
                            if (input.Equals("B")) { milkType = "BuffaloMilk";
                                //serialPort1.WriteLine("2-Buffalo");
                            }
                            else { milkType = "CowMilk";
                                //serialPort1.WriteLine("2-Cow");
                            }


                            string sql4 = "select * from Productout where poname ='" + milkType + "' ";
                            MySqlCommand cmd4 = new MySqlCommand(sql4, con);
                            con.Open();
                            MySqlDataReader sdr2 = cmd4.ExecuteReader();
                            if (sdr2.HasRows)
                            {
                                    while (sdr2.Read())
                                {
                                    poactualcost = float.Parse(sdr2["poactualcost"].ToString());
                                    poquantity = float.Parse(sdr2["poquantity"].ToString());
                                }
                                //serialPort1.WriteLine("2-DF");
                            }
                            else { serialPort1.WriteLine("2-No Data"); }


                            if (data[3].ToString().Equals("A\r") || (data[3].ToString().Equals("A")))
                            {
                                //serialPort1.WriteLine("2-in rupees");
                                totalprice = float.Parse(data[2].ToString());
                                orderQuantity = (totalprice / poactualcost);
                                
                            }
                            else
                            {
                                //serialPort1.WriteLine("2-in litre");
                                orderQuantity = float.Parse(data[2].ToString());
                                totalprice = (orderQuantity * poactualcost);
                            }

                            if (customerType.Equals("prepaid"))
                            {
                                //serialPort1.WriteLine("2-In prepaid");
                                if (depositAmt >= totalprice)
                                {
                                     output = "1- Balance : Rs" + depositAmt + "- Qty :" + orderQuantity + "- Bill:" + totalprice + "-Allowed";
                                    serialPort1.WriteLine(output);   
                                }
                                else output = "1- Balance : Rs" + depositAmt + "- Qty :" + orderQuantity + "- Bill:" + totalprice + "-Disallowed";
                                serialPort1.WriteLine(output);
                            }
                            else
                            {
                                output = "1- Credit : Rs" + balanceAmt + "- Qty :" + orderQuantity + "- Bill:" + totalprice + "-Allowed";
                                serialPort1.WriteLine(output);
                            }


                        }
                        else
                        { serialPort1.WriteLine("2-Please try again.");
                        }
                        con.Close();
                    }
                    break;

                default :
                    {
                        serialPort1.WriteLine("2-Invalid input");





                    }
                    break;
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
        }

        private void Send_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = textBox1.Text;
            textBox1.Text = "new port " + serialPort1.PortName.ToString();
        }
    }
}




