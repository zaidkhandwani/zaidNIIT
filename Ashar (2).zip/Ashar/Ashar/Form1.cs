﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ashar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.TopMost = true;
            //this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            tableLayoutPanel1.Width = this.Size.Width - (6 * (tableLayoutPanel1.Margin.Left));
            tableLayoutPanel2.Width = tableLayoutPanel1.Width;//this.Size.Width - (7 * (tableLayoutPanel2.Margin.Left));
            tableLayoutPanel3.Width = this.Size.Width - (7 * (tableLayoutPanel3.Margin.Left));
            tableLayoutPanel4.Width = this.Size.Width - (7 * (tableLayoutPanel4.Margin.Left));

            int cols = tableLayoutPanel3.ColumnCount;
            int wid = tableLayoutPanel3.Width / cols;
            for (int i = 0; i < cols; i++)
                tableLayoutPanel3.ColumnStyles[i].Width = wid;

        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            tableLayoutPanel1.Width = this.Size.Width - (5 * (tableLayoutPanel1.Margin.Left));
            tableLayoutPanel2.Width = this.Size.Width - (5 * (tableLayoutPanel2.Margin.Left));
            tableLayoutPanel3.Width = this.Size.Width - (5 * (tableLayoutPanel3.Margin.Left));
            tableLayoutPanel4.Width = this.Size.Width - (5 * (tableLayoutPanel4.Margin.Left));

            int cols = tableLayoutPanel3.ColumnCount;
            int wid = tableLayoutPanel3.Width / cols;
            for (int i = 0; i < cols; i++)
                tableLayoutPanel3.ColumnStyles[i].Width = wid;

            int cols2 = tableLayoutPanel4.ColumnCount;
            int wid2 = tableLayoutPanel4.Width / cols2;
            for (int i = 0; i < cols2; i++)
                tableLayoutPanel4.ColumnStyles[i].Width = wid2;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegisterForm rf = new RegisterForm();
            rf.StartPosition = FormStartPosition.CenterScreen;
            rf.Show();
         }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.StartPosition = FormStartPosition.CenterScreen;
            lf.Show();
        }
    }
}
