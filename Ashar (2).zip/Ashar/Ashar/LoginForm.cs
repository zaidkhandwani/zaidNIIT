﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ashar
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (txtUid.Text == null || txtUid.Text.Equals("")) { warningLabel.Text = "User Id Required !"; return; }
            if (txtPassword.Text == null || txtPassword.Text.Equals("")) { warningLabel.Text = "Password is Mandatory!"; return; }
            if (txtUid.Text.Equals("admin") && txtPassword.Text.Equals("admin@123"))
            {
                this.Close();
                UpdateTT tt = new UpdateTT();
                tt.StartPosition = FormStartPosition.CenterScreen;
                tt.Show();
            }
            else
            {
                warningLabel.Text = "Invalid Credentials!";
            }
        }
    }
}
