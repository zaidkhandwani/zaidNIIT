﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ashar
{
    public partial class RegisterForm : Form
    {
        string conn = System.Configuration.ConfigurationManager.AppSettings["myConnection"];
        string gender = "";
        string role = "";
        public RegisterForm()
        {
            InitializeComponent();
        }

     
        private void RegisterForm_Load(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {   
            if(txtName.Text.Equals("") || txtName == null)
            {
                warningLabel.Text = "Please fill your name !";
                return;
            }
            if(txtRfid.Text.Equals("") || txtRfid == null)
            {
                warningLabel.Text = "Please select the RFID field & Scan your card.";
                return;
            }
            //if((!radioStudent.Checked) && (!radioTeacher.Checked))
            //{
            //    warningLabel.Text = "Please select your Role !";
            //    return;
            //}
            if ((!radioMale.Checked) && (!radioFemale.Checked))
            {
                warningLabel.Text = "Please select Gender !";
                return;
            }
            if (radioMale.Checked)  gender = "Male";  else  gender = "Female"; 
            //if (radioStudent.Checked)
            //{
            //    role = "Student";
            //    if (rollNo.ToString().Equals("") || rollNo.ToString().Equals("0")) { warningLabel.Text = "Please Enter Your Roll No. !"; return; }
            //    if (batch.Text.Equals("") || batch == null) { warningLabel.Text = "Select Your Batch"; return; }
            //}
            //else role = "Teacher";
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
            {

                ////con.Open();
                ////string sql = "insert into User values('" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "','" + data1 + "')";
                ////System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);
                ////int i = cmd.ExecuteNonQuery();
            }
        }

        
    }
}
