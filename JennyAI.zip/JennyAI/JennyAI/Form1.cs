﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Speech.Recognition;
using Microsoft.Speech.Synthesis;
using System.Globalization;
using JennyAI.hedSms;

namespace JennyAI
{
    public partial class Form1 : Form
    {
        static SpeechSynthesizer ss = new SpeechSynthesizer();
        static SpeechRecognitionEngine sre;
        static bool done = false;
        static bool speechOn = true;
        string weather = "";
        string mobile = "";
        string psno = "";
        string empFather = "";
        string empGender = "";
        string conn = "Data Source = LNENTREP\\LNDB3IN;Initial Catalog = lnapppddb; User ID = web; Password=bew;MultipleActiveResultSets=True;";
        float jennyArduinoInput;

        hedSms.hedsms sms = new hedsms();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.Open();
        
            ss.SetOutputToDefaultAudioDevice();
            //ss.Speak("Hello. Welcome to the world of AI that is Artificial Intelligence. My name is Jenny. your personal Assistant.");
            ss.Speak("I am awake and listening");
            CultureInfo ci = new CultureInfo("en-us");
            sre = new SpeechRecognitionEngine(ci);
            sre.SetInputToDefaultAudioDevice();
            sre.SpeechRecognized += sre_SpeechRecognized;

            Choices ch_StartStopCommands = new Choices();
            ch_StartStopCommands.Add("speech on");
            ch_StartStopCommands.Add("speech off");
            ch_StartStopCommands.Add("klatu barada nikto");
            ch_StartStopCommands.Add("yes please");
            ch_StartStopCommands.Add("no");
            ch_StartStopCommands.Add("hello jenny");
            ch_StartStopCommands.Add("introduce yourself");
            ch_StartStopCommands.Add("thank you jenny");
            ch_StartStopCommands.Add("How are you jenny");
            ch_StartStopCommands.Add("Get me the Employee Details");
            ch_StartStopCommands.Add("age");
            ch_StartStopCommands.Add("name");
            ch_StartStopCommands.Add("name");


            ch_StartStopCommands.Add("goodbye jenny");
            GrammarBuilder gb_StartStop = new GrammarBuilder();
            gb_StartStop.Append(ch_StartStopCommands);
            Grammar g_StartStop = new Grammar(gb_StartStop);

            Choices ch_Numbers = new Choices();
            ch_Numbers.Add("1");
            ch_Numbers.Add("2");
            ch_Numbers.Add("3");
            ch_Numbers.Add("4"); // technically Add(new string[] { "4" });
            ch_Numbers.Add("5");
            ch_Numbers.Add("6");
            ch_Numbers.Add("7");
            ch_Numbers.Add("8");
            ch_Numbers.Add("9");
            ch_Numbers.Add("0");

            GrammarBuilder gb_nameAge = new GrammarBuilder();
            gb_nameAge.Append("What is your");
            gb_nameAge.Append(ch_StartStopCommands);
            
            Grammar g_nameAge = new Grammar(gb_nameAge);

            GrammarBuilder gb_WhatIsXplusY = new GrammarBuilder();
            gb_WhatIsXplusY.Append("What is");
            gb_WhatIsXplusY.Append(ch_Numbers);
            gb_WhatIsXplusY.Append("plus");
            gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar g_WhatIsXplusY = new Grammar(gb_WhatIsXplusY);


            Choices cmd = new Choices();
            Choices cmd2 = new Choices();
            Choices cmd3 = new Choices();
            Choices smsTo = new Choices();
            Choices msgContent = new Choices();
            //cmd.Add("turn");
            cmd.Add("on");
            cmd.Add("off");
            cmd.Add("hot");
            cmd.Add("cold");

            cmd2.Add("time");
            cmd2.Add("date");

            cmd3.Add("his");
            cmd3.Add("her");

            smsTo.Add("Nilesh Sir");
            smsTo.Add("Anurag");
            smsTo.Add("Ozair");
            smsTo.Add("Zaid");

            msgContent.Add("Hi");
            msgContent.Add("Hello");
            msgContent.Add("Temperature Report");


            //cmd.Add("fan");
            //GrammarBuilder gb_cmd = new GrammarBuilder();
            //gb_cmd.Append(cmd);
            //Grammar g_cmd = new Grammar(gb_cmd);
            GrammarBuilder gb_father = new GrammarBuilder();
            gb_father.Append("What is");
            gb_father.Append(cmd3);
            gb_father.Append("father's name");
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar g_father = new Grammar(gb_father);


            GrammarBuilder gb_fan = new GrammarBuilder();
            gb_fan.Append("Turn");
            gb_fan.Append(cmd);
            gb_fan.Append("fan");
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar gb_f = new Grammar(gb_fan);

            GrammarBuilder gb_psno6digit = new GrammarBuilder();
            gb_psno6digit.Append("PS number is ");
            gb_psno6digit.Append(ch_Numbers);
            gb_psno6digit.Append(ch_Numbers);
            gb_psno6digit.Append(ch_Numbers);
            gb_psno6digit.Append(ch_Numbers);
            gb_psno6digit.Append(ch_Numbers);
            gb_psno6digit.Append(ch_Numbers);
            Grammar g_psno6digit = new Grammar(gb_psno6digit);

            GrammarBuilder gb_psno8digit = new GrammarBuilder();
            gb_psno8digit.Append("PS number is ");
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            gb_psno8digit.Append(ch_Numbers);
            Grammar g_psno8digit = new Grammar(gb_psno8digit);



            GrammarBuilder gb_normal = new GrammarBuilder();
           // gb_normal.Append("yes");
            
            gb_normal.Append("no thanks");
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar gb_normalg = new Grammar(gb_normal);

            GrammarBuilder gb_smart = new GrammarBuilder();
            gb_smart.Append("Its");
            gb_smart.Append("getting");
            gb_smart.Append(cmd);
            gb_smart.Append("here");
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar gb_smartg = new Grammar(gb_smart);

            GrammarBuilder gb_sms = new GrammarBuilder();
            gb_sms.Append("Send");
            gb_sms.Append("sms to");
            gb_sms.Append(smsTo);
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar g_sms = new Grammar(gb_sms);

            GrammarBuilder gb_smsContent = new GrammarBuilder();
            gb_smsContent.Append("Send");
            gb_smsContent.Append("him");
            gb_smsContent.Append(msgContent);
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar g_smsContent = new Grammar(gb_smsContent);


            GrammarBuilder gb_dateTime = new GrammarBuilder();
            gb_dateTime.Append("What");
            gb_dateTime.Append("is");
            gb_dateTime.Append("the");
            gb_dateTime.Append(cmd2);
          
            //gb_WhatIsXplusY.Append(ch_Numbers);
            Grammar gb_dateTimeg = new Grammar(gb_dateTime);

            sre.LoadGrammarAsync(g_psno6digit);
            sre.LoadGrammarAsync(g_psno8digit);
            sre.LoadGrammarAsync(g_smsContent);
            sre.LoadGrammarAsync(g_sms);
            sre.LoadGrammarAsync(g_nameAge);
            sre.LoadGrammarAsync(gb_dateTimeg);
            sre.LoadGrammarAsync(gb_normalg);
            sre.LoadGrammarAsync(gb_smartg);
            sre.LoadGrammarAsync(g_StartStop);
            sre.LoadGrammarAsync(g_WhatIsXplusY);
            sre.LoadGrammarAsync(gb_f);
            sre.LoadGrammarAsync(g_father);

            sre.RecognizeAsync(RecognizeMode.Multiple); // multiple grammars

            //while (done == false) { ; }
            backgroundWorker1.RunWorkerAsync();

        }

       public void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            string txt = e.Result.Text;
            float confidence = e.Result.Confidence; // consider implicit cast to double
           // Console.WriteLine("\nRecognized: " + txt);

            if (confidence < 0.60) return;

            if (txt.IndexOf("speech on") >= 0)
            {
                Console.WriteLine("Speech is now ON");
                speechOn = true;
            }

            if (txt.IndexOf("speech off") >= 0)
            {
                Console.WriteLine("Speech is now OFF");
                speechOn = false;
            }
          
            if (speechOn == false) return;

            if (txt.IndexOf("klatu") >= 0 && txt.IndexOf("barada") >= 0)
            {
                ((SpeechRecognitionEngine)sender).RecognizeAsyncCancel();
                done = true;
                Console.WriteLine("(Speaking: Farewell)");
                ss.Speak("Farewell");
            }

            if (txt.IndexOf("What") >= 0 && txt.IndexOf("plus") >= 0) // what is 2 plus 3
            {
                string[] words = txt.Split(' ');     // or use e.Result.Words
                int num1 = int.Parse(words[2]);
                int num2 = int.Parse(words[4]);
                int sum = num1 + num2;
                Console.WriteLine("(Speaking: " + words[2] + " plus " + words[4] + " equals " + sum + ")");
                ss.SpeakAsync(words[2] + " plus " + words[4] + " equals " + sum);
            }


                if (txt.IndexOf("Turn") >= 0 && txt.IndexOf("fan") >= 0)
                {
                   
                    string[] words = txt.Split(' ');     // or use e.Result.Words
                    if (words[1].Equals("on"))
                    {
                        label1.Text = "Fan on";
                        ss.SpeakAsync("Turning fan on");
                        serialPort1.Write("1");
                    }
                    else if (words[1].Equals("off"))
                    {
                        label1.Text = "Fan off";
                        ss.SpeakAsync("Turning fan off");
                        serialPort1.Write("0");
                    }
                }

                if (txt.IndexOf("What") >= 0 && txt.IndexOf("the") >= 0)
                {
                    string[] words = txt.Split(' ');     // or use e.Result.Words
                    if (words[3].Equals("date"))
                    {
                        label1.Text = "Current Date";
                        string date = DateTime.Now.ToString("dd-MMM-yyyy");
                        ss.SpeakAsync(date);
                        // serialPort1.Write("1");
                    }
                    else if (words[3].Equals("time"))
                    {
                        label1.Text = "Current Time";
                        string date = DateTime.Now.ToString("h:m");
                        //label1.Text = "Current Time";
                        string[] date1 = date.Split(':');
                        ss.SpeakAsync("Its "+date1[0]+" hours and "+date1[1]+" minutes");
                        //serialPort1.Write("0");
                    }

                }

                if (txt.IndexOf("Its") >= 0 && txt.IndexOf("getting") >= 0)
                {

                    string[] words = txt.Split(' ');     // or use e.Result.Words
                    if (words[2].Equals("hot"))
                    {
                        label1.Text = "Hot";
                        ss.SpeakAsync("Should I turn on the fan Sir");
                        weather="hot";
                        
                    }
                    else if (words[2].Equals("cold"))
                    {
                        label1.Text = "cold";
                        ss.SpeakAsync("Should I turn off the fan Sir");
                        weather = "cold";
                    }

                }

                if (txt.IndexOf("yes please") >= 0 )
                {

                    if (weather.Equals("hot")) { 
                    
                        label1.Text = "Fan on";
                        ss.SpeakAsync("Turning fan on");
                        serialPort1.Write("1");
                    }
                    else if (weather.Equals("cold"))
                    {
                        label1.Text = "Fan off";
                        ss.SpeakAsync("Turning fan off");
                        serialPort1.Write("0");
                    }
                   
                }
                if (txt.IndexOf("no") >= 0)
                {
                    ss.SpeakAsync("OK Sir");
                }
                if (txt.IndexOf("hello jenny") >= 0)
                {
                    ss.SpeakAsync("Hello Sir how can i help you");
                }
                if (txt.IndexOf("introduce yourself") >= 0)
                {
                    ss.SpeakAsync("Hello. My name is Jenny. your personal Assistant.");
                }

                 if (txt.IndexOf("Get me the Employee Details") >= 0)
                {
                    ss.SpeakAsync("Sure sir. What is the PS number?");
                }

                if (txt.IndexOf("thank you jenny") >= 0)
                {
                    ss.SpeakAsync("you are welcome sir");
                }
                if (txt.IndexOf("How are you jenny") >= 0)
                {
                    ss.SpeakAsync("i am fine sir");
                }
            if (txt.IndexOf("What is "+empGender+" father's name") >= 0)
            {
                ss.SpeakAsync(empGender+" father's name is "+empFather);
            }
            if (txt.IndexOf("What is your ") >= 0)
                {
                string[] words = txt.Split(' ');     
                if (words[3].Equals("age")) { 
                    ss.SpeakAsync("i was created on this valentine day by Anurag and Zaid");
                    }
                else if (words[3].Equals("name"))
                {
                    ss.SpeakAsync("My name is jenny");
                    }
                }

                if (txt.IndexOf("goodbye jenny") >= 0)
                {
                    ss.SpeakAsync("goodbye sir");
                    Application.Exit();
                }

            if (txt.IndexOf("Send") >= 0 && txt.IndexOf("sms") >= 0)
            {

                string[] words = txt.Split(' ');     // or use e.Result.Words

                switch (words[3])
                {
                    case "Anurag": {
                            ss.SpeakAsync("Yes sure. What should i send");
                            mobile = "8652117127";
                            break;
                        }
                    case "Nilesh":
                        {
                            ss.SpeakAsync("Yes sure. What should i send");
                            mobile = "8291111211";
                            break;
                        }
                    case "Ozair":
                        {
                            ss.SpeakAsync("Yes sure. What should i send");
                            mobile = "9029607828";
                            break;
                        }
                }
            }


            if (txt.IndexOf("Send") >= 0 && txt.IndexOf("him") >= 0)
            {
                ss.SpeakAsync("in loop");
                string[] words = txt.Split(' ');     // or use e.Result.Words
                ss.SpeakAsync("Sending SMS");
                switch (words[2])
                {
                    case "Hi":
                        {
                            //ss.SpeakAsync("Sending SMS");
                            sms.sendSMS("172.16.7.125", "hedweb", "Zaid", "Zaid", mobile, "Hi! \n" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss") + "\n Jenny from L&T HED");
                           
                            break;
                        }
                    case "Hello":
                        {
                            //.SpeakAsync("Sending SMS");
                            sms.sendSMS("172.16.7.125", "hedweb", "Zaid", "Zaid", mobile, "Hello! \n" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss") + "\n Jenny from L&T HED");
                           // ss.SpeakAsync("SMS Sent");
                            break;
                        }
                    case "Temperature":
                        {
                           // ss.SpeakAsync("Sending SMS");
                            sms.sendSMS("172.16.7.125", "hedweb", "Zaid", "Zaid", mobile, "TemperatureReport \n" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss") + "\n Jenny from L&T HED");
                            //ss.SpeakAsync("SMS Sent");
                            break;
                        }
                }
                ss.SpeakAsync("SMS Sent");
            }

            if (txt.IndexOf("PS ") >= 0 && txt.IndexOf("number") >= 0)
            {

                string[] words = txt.Split(' ');  
                
                if (words.Length==9)
                {
                    
                    psno = words[3] + words[4] + words[5] + words[6] + words[7] + words[8];
                    label1.Text = psno;
                    
                    using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
                    {
                        con.Open();
                        string sql = "select * from tltcom001180 where t_psno='"+psno+"'";
                        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);
                        System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            while (sdr.Read()) {
                                ss.SpeakAsync("PS number belongs to "+sdr["t_name"].ToString());
                                empFather = sdr["t_fshb"].ToString();
                                empGender = sdr["t_sexx"].ToString();
                                if (empGender.Equals("2")) empGender = "her";
                                else if (empGender.Equals("1")) empGender = "his";
                            }
                        }
                        else
                        {
                            ss.SpeakAsync("PS number does not exist");
                        }
                    }

                }
                else if (words.Length == 11)
                {
                    psno = words[3] + words[4] + words[5] + words[6] + words[7] + words[8] + words[9] + words[10];
                    label1.Text = psno;
                    using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
                    {
                        con.Open();
                        string sql = "select * from tltcom001180 where t_psno='" + psno + "'";
                        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con);
                        System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            while (sdr.Read())
                            {
                                ss.SpeakAsync("PS number belongs to " + sdr["t_name"].ToString().ToLower());
                                empFather= sdr["t_fshb"].ToString();
                                empGender = sdr["t_sexx"].ToString();
                            }
                        }
                        else
                        {
                            ss.SpeakAsync("PS number does not exist");
                        }
                    }
                }

            }
        }

        private void portsadd()
       {
        
       }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            jennyArduinoInput = float.Parse(serialPort1.ReadLine());
            if (jennyArduinoInput >= 40)
            {
                ss.SpeakAsync("Temperature Alert");
                textBox1.Invoke((MethodInvoker)delegate { textBox1.Text = "Temperature ALert"; });
            }
            
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // sre_SpeechRecognized

    }
}
